import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from 'src/services/api.service';
import { DataService } from 'src/services/data.service';

declare var $: any;
@Component({
	selector: 'app-admin-navbar',
	templateUrl: './admin-navbar.component.html',
	styleUrls: ['./admin-navbar.component.css']
})
export class AdminNavbarComponent implements OnInit {
	@Input('isLoggedIn') isLoggedIn: Boolean = true;

	adminPic: any;
	adminId: any;
	imageUrl: any = '../../assets/images/Grabguidance PP@2x.png';
	oldpass: string;
	newpass: string;
	usrSession = []
	sessDur = []
	expSession = []
	selectedItems = [];
	selectedDur = []
	selectedExp = []
	dropdownSettings: IDropdownSettings;
	dropdownSettingsExperts: IDropdownSettings;
	dropdownSettingsDuration: IDropdownSettings;
	constructor(
		private route: Router,
		private apiService: ApiService,
		private toastr: ToastrService,
		private dataService: DataService,
		private sanitizer: DomSanitizer
	) { }

	ngOnInit(): void {
		this.fetchAdminProfilePitcher();
		this.adminId = localStorage.getItem('id_admin');
		this.userForSession()
		this.expertForSession()
		this.sessionDuration()
		this.dropdownSettings = {
			singleSelection: false,
			idField: 'id_user',
			textField: 'full_name',
			selectAllText: 'Select All',
			unSelectAllText: 'UnSelect All',
			itemsShowLimit: 7,
			allowSearchFilter: true,
		};
		this.dropdownSettingsExperts = {
			singleSelection: true,
			idField: 'id_expert',
			textField: 'full_name',
			selectAllText: 'Select Experts',
			unSelectAllText: 'UnSelect All',
			itemsShowLimit: 7,
			allowSearchFilter: true,
		};
		this.dropdownSettingsDuration = {
			singleSelection: true,
			idField: 'id_expert',
			textField: 'full_name',
			selectAllText: 'Select Experts',
			unSelectAllText: 'UnSelect All',
			itemsShowLimit: 7,
			allowSearchFilter: true,
		};
	}

	logout() {
		localStorage.clear();
		sessionStorage.clear();
		this.dataService.setUserLoggingStatus(null);
		this.route.navigate(['/']);
	}

	ChangePassword() { }

	onSubmit() {
		let oldPassword: string = this.oldpass;
		let newPassword: string = this.newpass;
		this.apiService.adminChangePassword(this.adminId, oldPassword, newPassword).subscribe(
			(res) => {
				if (res.code == 1000) {
					this.toastr.success('Your password is changed successfully');
				} else if (res.code == 1001) {
					this.toastr.error(res.status);
				} else {
					this.toastr.error('Error in changing password');
				}
			},
			(err) => {
				this.toastr.error('Error in changing password');
			}
		);
	}


	userForSession() {

		this.apiService.fetchUsersForSession().subscribe(
			(res) => {
				this.usrSession = res.users


			},
			(err) => {
				this.toastr.error('Error in changing password');
			}
		);
	}

	expertForSession() {

		this.apiService.fetchExpertsForSession().subscribe(
			(res) => {
				this.expSession = res.experts


			},
			(err) => {
				this.toastr.error('Error in changing password');
			}
		);
	}

	sessionDuration() {
		this.sessDur = [{ id: 1, time: 20 }, { id: 2, time: 40 }, { id: 3, time: 60 }]


	}

	dasboard() {
		this.route.navigate(['/admin/dashboard']);
	}

	fetchAdminProfilePitcher() {
		this.adminPic = localStorage.getItem('admin_pic');
		if (this.adminPic) {
			var base64String = btoa(
				new Uint8Array(this.adminPic).reduce(function (data, byte) {
					return data + String.fromCharCode(byte);
				}, '')
			);
			this.imageUrl = this.sanitizer.bypassSecurityTrustResourceUrl('data:image/jpeg;base64,' + base64String);
		}
	}

	openBookMultipleSessions() {
		$('#bookMultipleSessions').modal('show');
	}
}
